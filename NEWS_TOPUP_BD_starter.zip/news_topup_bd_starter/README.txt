NEWS TOPUP BD starter project

web/
  index.html       Responsive Bengali top-up storefront demo
  manifest.json    Installable web app metadata
  sw.js            Minimal service worker

Important:
- This is a front-end prototype, not a live top-up service.
- No real payment is collected and no diamonds are delivered.
- Before launch, add a secure backend, admin login, verified supplier/API,
  correct prices, customer support details, privacy policy and tested payment
  integration. Never ask customers to share PINs or OTPs.
- Do not use Garena/Free Fire logos or character artwork without permission.
- The Android folder is a placeholder; build/signing an APK requires Android
  Studio/Android SDK and app configuration.
